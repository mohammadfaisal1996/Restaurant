<script src="https://oppwa.com/v1/paymentWidgets.js?checkoutId=<?php echo $_GET['id']?>"></script>
<form action="https://dashboard.bluefig.digisolapps.com/paymentHyper/success.php" class="paymentWidgets" data-brands="VISA MASTER AMEX"></form>
<script type="text/javascript"> 
var wpwlOptions = {
paymentTarget:"_top",
}

 
 

</script>
<style>
  .wpwl-wrapper{         font-size:18px !important;;
} .wpwl-wrapper-cardNumber{         font-size:18px !important;;
}

       body{
           
            
background-color:black;
      }
     
      .wpwl-label{
          color:white;
       }

    .wpwl-form-card {
     min-height: 20% !important;
     color:gray;
    margin-top:25%;
    background:linear-gradient(120deg, #1a1f71, #f7b600);
     zoom: 190%;
}
 
    ::placeholder {
  color: gray;
 }

    
   @media only screen and (max-width: 600px) and (min-width: 200px)  {
      .wpwl-group-cardNumber .wpwl-group-cardHolder .wpwl-group-birthDate{
         font-size:180000px !important;;
        font-weight:bold !important;;
     }
        .wpwl-form-card{
            width:100%;
            background-color:red !important;
             zoom: 200%;
        }
          .wpwl-form-card {
               width: 100% !important;
    height: 30% !important;
    align items:center
               
          }
              
}
    
</style>