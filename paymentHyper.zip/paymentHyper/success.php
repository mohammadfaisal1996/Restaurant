<?php
    include "../connectionDb.php";
// 	include "loading.php";
    $database = new connectionDb();
    $db = $database->getConnection();
    $id=$_GET["id"];
	$url = "https://oppwa.com/v1/checkouts/{$id}/payment";
	$url .= "?entityId=8ac9a4cc73575ab201736640e7a6709f";
	
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                  'Authorization:Bearer OGFjOWE0Y2M3MzU3NWFiMjAxNzM2NjQwNzQxYzcwOWF8NFpYRHR3N1NzOQ=='));
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);// this should be set to true in production
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$responseData = curl_exec($ch);
	if(curl_errno($ch)) {
		return curl_error($ch);
	}
	curl_close($ch);
	$data= json_decode ($responseData);
	$code=$data->result->code;
	

    
	$orderQuery="SELECT  order_id,OrderNumber,user_token  FROM  `ordersMaster` where checkout_id ='$id'";
    $order_id_execute=$db->prepare($orderQuery);
    if($order_id_execute->execute()) {
        $row = $order_id_execute->fetch(PDO::FETCH_ASSOC);
        $order_id = $row["order_id"];
        $OrderNumber = $row["OrderNumber"];
        $user_token = $row["user_token"];
        $pattern="/^(000\.000\.|000\.100\.1|000\.[36])/";

	if(isset($code) &&  preg_match($pattern, $code)){


        $order = "UPDATE `ordersMaster` set `order_status`=1  where order_id=$order_id and checkout_id ='$id'";
        $order = $db->prepare($order);
        if ($order->execute()) {
            $NewOrder_url = "http://node.bluefig.digisolapps.com:8025/NewOrder?order_id=".$order_id."&Token=".$user_token."&NUMB=".$OrderNumber;
            $payment_success_url = "http://node.bluefig.digisolapps.com:8025/payment-success";
            CurlRequest($NewOrder_url,$order_id);
            CurlRequest($payment_success_url,  $order_id);
            header('Content-type: application/json');
            echo  json_encode(["status" => "success"]);
        } else {
            http_response_code(401);
            echo  http_response_code();
        }
    
	}else{
           $payment_fail_url = "http://node.bluefig.digisolapps.com:8025/payment-fail?Token=$user_token&order_number=$OrderNumber&code=$code";
           CurlRequest($payment_fail_url,$order_id);
	}

    
    }
    // var_dump($data);
    
function CurlRequest($url,$order_id){

    $curl = curl_init();
    $fields = array(
        'order_id' => $order_id,
    );

    $fields_string = http_build_query($fields);

    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt( $curl, CURLOPT_CUSTOMREQUEST, 'GET' );
    curl_setopt($curl, CURLOPT_POSTFIELDS, $fields_string);
    $data = curl_exec($curl);
    curl_close($curl);
}


?>