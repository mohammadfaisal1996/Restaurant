<?php

include "../connectionDb.php";
$database = new connectionDb();
$db = $database->getConnection();
    
        
if(isset($_GET['amount'])&&isset($_GET['order_id'])){
    $amount=$_GET['amount'];
    $order_id=$_GET['order_id'];

	$url = "https://oppwa.com/v1/checkouts";
	$data = "entityId=8ac9a4cc73575ab201736640e7a6709f" .
                "&amount=$amount".
                "&currency=JOD" .
                "&paymentType=DB";

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                  'Authorization:Bearer OGFjOWE0Y2M3MzU3NWFiMjAxNzM2NjQwNzQxYzcwOWF8NFpYRHR3N1NzOQ=='));
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);// this should be set to true in production
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$responseData = curl_exec($ch);
	if(curl_errno($ch)) {
		return curl_error($ch);
	}
	curl_close($ch);
	$data=json_decode($responseData);
	$query="UPDATE `ordersMaster` set `checkout_id` = '".$data->id."' WHERE order_id=$order_id";
    $order_id_execute=$db->prepare($query);
    if($order_id_execute->execute()) {

    }
    echo $responseData;

}else{
    echo "amount required or  order_id required";
}


?>